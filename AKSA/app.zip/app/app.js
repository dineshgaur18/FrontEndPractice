(function(){
  var basketApp = angular.module("basketApp",["ui.router"]);

  
  basketApp.constant("Constants",{
    CurrencySymbol:"$"
    
  });

})();