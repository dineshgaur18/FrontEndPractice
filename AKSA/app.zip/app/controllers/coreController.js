(function(){
  angular
    .module("basketApp")
    .controller("coreController", coreController);

    function coreController()
    {
        var vm = this;

    }

})();